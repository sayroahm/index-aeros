#!/bin/bash
set -e
rm -f build/*.o build/*.elf
make build/kernel.elf
sudo losetup -P /dev/loop0 build/AerOS.img
sudo mount /dev/loop0p1 /mnt/aeros
sudo cp build/kernel.elf /mnt/aeros/boot/kernel.elf
sudo umount /mnt/aeros
sudo losetup -d /dev/loop0
qemu-img convert -f raw -O vmdk -o adapter_type=ide build/AerOS.img build/AerOS.vmdk
echo "Done! Boot AerOS in VMware."
