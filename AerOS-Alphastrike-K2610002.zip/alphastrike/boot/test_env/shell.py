import time
import os

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def help():
    print("Available commands:")
    print("  help - show this help message")
    print("  clear - clear the screen")
    print("  exit - exit the shell")
    print("  time - show the current time")
    print("  echo - repeat text")

print("""
   █████████                         ███████     █████████ 
  ███▒▒▒▒▒███                      ███▒▒▒▒▒███  ███▒▒▒▒▒███
 ▒███    ▒███   ██████  ████████  ███     ▒▒███▒███    ▒▒▒ 
 ▒███████████  ███▒▒███▒▒███▒▒███▒███      ▒███▒▒█████████ 
 ▒███▒▒▒▒▒███ ▒███████  ▒███ ▒▒▒ ▒███      ▒███ ▒▒▒▒▒▒▒▒███
 ▒███    ▒███ ▒███▒▒▒   ▒███     ▒▒███     ███  ███    ▒███
 █████   █████▒▒██████  █████     ▒▒▒███████▒  ▒▒█████████ 
▒▒▒▒▒   ▒▒▒▒▒  ▒▒▒▒▒▒  ▒▒▒▒▒        ▒▒▒▒▒▒▒     ▒▒▒▒▒▒▒▒▒  
                                                           
      shell version 0.1 - type 'help' for a list of commands                                                     
                                                                                             
    """)
def shell():
    
    print("~>")
    while True: 
        cmd = input("aerOS> ").strip().lower()

        if cmd == "help":
            help()
        elif cmd == "clear":
            clear()
        elif cmd == "exit":
            break
        elif cmd == "time":
            print("Current time:", time.ctime())

        elif cmd.startswith("echo "):
            print(cmd[5:])
        elif cmd == "":
            continue
        else:

            print("Unknown command. Type 'help' for a list of commands.")

shell()


# *                         AERO OPERATING SYSTEM
# *             COPYRIGHT (C) 2026 Cortlin. All rights reserved.
# * | FT.      | AUTHOR.     | DESC.           | DATE COMPILED         | BD. PROD.       |
# * | Smpl. K.H| Max Mays    | Fake Shell      | 2026-05-4 19:01:00    | 2600.1001       |
# * |          |             |                 |                       |                 |
# * |__|__|__|__|__|__|__|__|__|__|___|__|__|__|__|__|__|__|__|__|__|__|__|__|__|__|__|__|
# * TODO: - Add more commands to the shell