#pragma once

// hardware io
static inline unsigned char inb(unsigned short port) {
    unsigned char r;
    __asm__ volatile("inb %1,%0":"=a"(r):"Nd"(port));
    return r;
}
static inline void outb(unsigned short port, unsigned char val) {
    __asm__ volatile("outb %0,%1"::"a"(val),"Nd"(port));
}

// multiboot
typedef struct {
    unsigned int flags,mem_lower,mem_upper,boot_device,cmdline,mods_count,mods_addr;
    unsigned int syms[4],mmap_length,mmap_addr,drives_length,drives_addr;
    unsigned int config_table,boot_loader_name,apm_table;
    unsigned int vbe_control_info,vbe_mode_info;
    unsigned short vbe_mode,vbe_interface_seg,vbe_interface_off,vbe_interface_len;
    unsigned long long framebuffer_addr;
    unsigned int framebuffer_pitch,framebuffer_width,framebuffer_height;
    unsigned char framebuffer_bpp,framebuffer_type;
} __attribute__((packed)) multiboot_info_t;

// colors
#define COL_DESKTOP  0x006060CC
#define COL_TASKBAR  0x00202020
#define COL_TASKBTN  0x00404040
#define COL_TASKACT  0x00000080
#define COL_MENUBAR  0x00D4D0C8
#define COL_BLACK    0x00000000
#define COL_WHITE    0x00FFFFFF
#define COL_GRAY     0x00C0C0C0
#define COL_DARK     0x00808080
#define COL_SHADOW   0x00404040
#define COL_TITLEBG  0x00000080
#define COL_TITLEFG  0x00FFFFFF
#define COL_WINBG    0x00C0C0C0
#define COL_RED      0x00CC0000
#define COL_GREEN    0x0000AA00
#define COL_BLUE     0x000000CC
#define COL_SELBG    0x00000080
#define COL_SELFG    0x00FFFFFF
#define COL_TERMINAL 0x00001800
#define COL_TERMFG   0x0000FF00
#define COL_MENUHOV  0x00000080
#define COL_MINBTN   0x00888800
#define COL_STARTBG  0x00001060
#define COL_STARTHOV 0x000020A0

#define FONT_W 8
#define FONT_H 10

// window id
#define MAX_WINDOWS  16
#define WIN_FILES    0
#define WIN_SHELL    1
#define WIN_VIEWER   2
#define WIN_EDITOR   3
#define WIN_SETTINGS 4
#define WIN_SYSINFO  5

// f-s
#define PART2_OFFSET  65536
#define SECTOR_SIZE   512
#define ROOT_START    96
#define ROOT_SECTORS  32
#define DATA_START    158
#define CLUSTER_SIZE  2
#define MAX_FILES     64

// settings
typedef struct {
    int start_fullscreen;
    int show_topbar;
    int font_bold;
    int size_unit;
    int font_scale; 
} Settings;

// file info
typedef struct {
    char         name[13];
    unsigned int size;
    int          is_dir,is_app;
    unsigned int cluster;
    int          entry_index;
} FileInfo;

// fat entry
typedef struct {
    char           name[8],ext[3];
    unsigned char  attr,reserved[10];
    unsigned short time,date,cluster;
    unsigned int   size;
} __attribute__((packed)) fat_entry_t;

// window
typedef struct {
    int x,y,w,h;
    const char* title;
    int visible,minimized,dragging,drag_ox,drag_oy;
} Window;

extern unsigned int fb_width,fb_height,fb_pitch;
extern Settings settings;
extern FileInfo file_list[MAX_FILES];
extern int file_count;
extern char file_content[4096];
extern int file_content_len;
extern Window windows[MAX_WINDOWS];
extern int win_count,focused_win;
extern int mouse_x,mouse_y,mouse_btn,mouse_btn_prev;
extern int right_btn,right_btn_prev;

// display.c
void put_pixel(int x,int y,unsigned int color);
void flush(void);
void draw_rect(int x,int y,int w,int h,unsigned int color);
void draw_rect_outline(int x,int y,int w,int h,unsigned int color);
void draw_char(int x,int y,char c,unsigned int fg,unsigned int bg);
void draw_string(int x,int y,const char* str,unsigned int fg,unsigned int bg);
void draw_string_scaled(int x,int y,const char* str,unsigned int fg,unsigned int bg,int scale);

int  str_len(const char* s);
int  str_eq(const char* a,const char* b);
void str_copy(char* d,const char* s);
void int_to_str(unsigned int n,char* buf);
void format_size(unsigned int bytes,char* buf);

// mouse.c
void mouse_init(void);
void mouse_poll(void);
int  mouse_clicked(void);
int  right_clicked(void);
void draw_cursor(void);

// keyboard.c
char read_key(void);

// fat.c
void read_sector(unsigned int lba,unsigned char* buf);
void write_sector(unsigned int lba,unsigned char* buf);
void load_file_list(void);
void open_file(unsigned int cluster);
int  create_file(const char* name,const char* ext);
void save_file(unsigned int cluster,const char* content,unsigned int len,int entry_index);
unsigned int fat_find_free_cluster(void);
void fat_set_cluster(unsigned int cluster,unsigned int val);
void write_cluster(unsigned int cluster,const char* content,unsigned int len);

// windows.c
void add_window(int x,int y,int w,int h,const char* title);
void focus_window(int i);
void draw_window_frame(int i);
void handle_window_drag(void);

// ui.c
void draw_desktop(void);
void draw_menubar(void);
void draw_taskbar(void);
void draw_start_menu(void);
void draw_about_dialog(void);
void draw_newfile_dialog(void);
void draw_context_menu(void);
void handle_ui_click(void);

// apps.c
void draw_file_explorer(void);
void draw_shell_content(void);
void draw_file_viewer(void);
void draw_editor(void);
void draw_settings(void);
void draw_sysinfo(void);
void shell_println(const char* str);
void shell_run(const char* cmd);
void editor_open(int idx);
void editor_save(void);
void editor_handle_key(char c);
void handle_keyboard(char c);
void handle_mouse_input(void);


// *                         AERO OPERATING SYSTEM
// *             COPYRIGHT (C) 2026 Cortlin. All rights reserved.
// * | FT.      | AUTHOR.     | DESC.                  | DATE COMPILED         | BD. PROD.      |
// * | Smpl. D.C| Evan Sakers | Core dspl. cnt > krnl  | 2026-05-4 18:39:00    | 2600.0011      |
// * |          |             |                        |                       |                |
// * |__________|_____________|________________________|_______________________|________________|
// * TODO: settings, display capabilities, kernel native support, .NET attributes, etc....
// * Source code reserved inside Cortlin database. Distribution of any sorts within an un-
// * -authorized third party is strictly prohibited. Contact an executive regarding furth-
// * -er notice about this file and its orgins of copyrights.