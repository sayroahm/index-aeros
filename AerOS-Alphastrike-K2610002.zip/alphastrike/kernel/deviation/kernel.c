#include "kernel.h"

// ═══════════════════════════════════════════════════════════════════════════════
// DISPLAY
// ═══════════════════════════════════════════════════════════════════════════════

static unsigned int* framebuffer;
static unsigned int  fb_width;
static unsigned int  fb_height;
static unsigned int  fb_pitch;
static unsigned int  backbuffer[1024 * 768];

void put_pixel(int x, int y, unsigned int color) {
    if (x < 0 || x >= (int)fb_width || y < 0 || y >= (int)fb_height) return;
    backbuffer[y * fb_width + x] = color;
}

void flush() {
    unsigned int pitch4 = fb_pitch / 4;
    for (unsigned int y = 0; y < fb_height; y++)
        for (unsigned int x = 0; x < fb_width; x++)
            framebuffer[y * pitch4 + x] = backbuffer[y * fb_width + x];
}

void draw_rect(int x, int y, int w, int h, unsigned int color) {
    for (int dy = 0; dy < h; dy++)
        for (int dx = 0; dx < w; dx++)
            put_pixel(x + dx, y + dy, color);
}

void draw_rect_outline(int x, int y, int w, int h, unsigned int color) {
    for (int dx = 0; dx < w; dx++) {
        put_pixel(x + dx, y,         color);
        put_pixel(x + dx, y + h - 1, color);
    }
    for (int dy = 0; dy < h; dy++) {
        put_pixel(x,         y + dy, color);
        put_pixel(x + w - 1, y + dy, color);
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// COLORS
// ═══════════════════════════════════════════════════════════════════════════════

#define COL_DESKTOP  0x006060CC
#define COL_TASKBAR  0x00202020
#define COL_TASKBTN  0x00404040
#define COL_TASKACT  0x00000080
#define COL_MENUBAR  0x00D4D0C8
#define COL_BLACK    0x00000000
#define COL_WHITE    0x00FFFFFF
#define COL_GRAY     0x00C0C0C0
#define COL_DARK     0x00808080
#define COL_SHADOW   0x00404040
#define COL_TITLEBG  0x00000080
#define COL_TITLEFG  0x00FFFFFF
#define COL_WINBG    0x00C0C0C0
#define COL_RED      0x00CC0000
#define COL_BLUE     0x000000CC
#define COL_SELBG    0x00000080
#define COL_SELFG    0x00FFFFFF
#define COL_TERMINAL 0x00001800
#define COL_TERMFG   0x0000FF00
#define COL_MENUHOV  0x00000080
#define COL_MINBTN   0x00888800

// ═══════════════════════════════════════════════════════════════════════════════
// FONT (8x10 bold)
// ═══════════════════════════════════════════════════════════════════════════════

#define FONT_W 8
#define FONT_H 10

static const unsigned char font[128][10] = {
    [' '] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    ['A'] = {0x3C,0x7E,0xC3,0xC3,0xFF,0xFF,0xC3,0xC3,0x00,0x00},
    ['B'] = {0xFE,0xFF,0xC3,0xFF,0xFE,0xFF,0xC3,0xFF,0x00,0x00},
    ['C'] = {0x3C,0x7E,0xC3,0xC0,0xC0,0xC3,0x7E,0x3C,0x00,0x00},
    ['D'] = {0xFC,0xFE,0xC3,0xC3,0xC3,0xC3,0xFE,0xFC,0x00,0x00},
    ['E'] = {0xFF,0xFF,0xC0,0xFE,0xFE,0xC0,0xFF,0xFF,0x00,0x00},
    ['F'] = {0xFF,0xFF,0xC0,0xFE,0xFE,0xC0,0xC0,0xC0,0x00,0x00},
    ['G'] = {0x3C,0x7E,0xC0,0xCF,0xCF,0xC3,0x7E,0x3C,0x00,0x00},
    ['H'] = {0xC3,0xC3,0xC3,0xFF,0xFF,0xC3,0xC3,0xC3,0x00,0x00},
    ['I'] = {0xFF,0xFF,0x18,0x18,0x18,0x18,0xFF,0xFF,0x00,0x00},
    ['J'] = {0x0F,0x0F,0x06,0x06,0xC6,0xC6,0xFE,0x7C,0x00,0x00},
    ['K'] = {0xC3,0xC6,0xCC,0xF8,0xF8,0xCC,0xC6,0xC3,0x00,0x00},
    ['L'] = {0xC0,0xC0,0xC0,0xC0,0xC0,0xC0,0xFF,0xFF,0x00,0x00},
    ['M'] = {0xC3,0xE7,0xFF,0xDB,0xC3,0xC3,0xC3,0xC3,0x00,0x00},
    ['N'] = {0xC3,0xE3,0xF3,0xDB,0xCF,0xC7,0xC3,0xC3,0x00,0x00},
    ['O'] = {0x3C,0x7E,0xC3,0xC3,0xC3,0xC3,0x7E,0x3C,0x00,0x00},
    ['P'] = {0xFE,0xFF,0xC3,0xFF,0xFE,0xC0,0xC0,0xC0,0x00,0x00},
    ['Q'] = {0x3C,0x7E,0xC3,0xC3,0xCB,0xCF,0x7E,0x3D,0x00,0x00},
    ['R'] = {0xFE,0xFF,0xC3,0xFF,0xFE,0xCC,0xC6,0xC3,0x00,0x00},
    ['S'] = {0x7E,0xFF,0xC0,0xFE,0x7F,0x03,0xFF,0x7E,0x00,0x00},
    ['T'] = {0xFF,0xFF,0x18,0x18,0x18,0x18,0x18,0x18,0x00,0x00},
    ['U'] = {0xC3,0xC3,0xC3,0xC3,0xC3,0xC3,0xFF,0x7E,0x00,0x00},
    ['V'] = {0xC3,0xC3,0xC3,0xC3,0x66,0x66,0x3C,0x18,0x00,0x00},
    ['W'] = {0xC3,0xC3,0xC3,0xDB,0xFF,0xFF,0xE7,0xC3,0x00,0x00},
    ['X'] = {0xC3,0x66,0x3C,0x18,0x18,0x3C,0x66,0xC3,0x00,0x00},
    ['Y'] = {0xC3,0x66,0x3C,0x18,0x18,0x18,0x18,0x18,0x00,0x00},
    ['Z'] = {0xFF,0xFF,0x06,0x0C,0x18,0x30,0xFF,0xFF,0x00,0x00},
    ['a'] = {0x00,0x3E,0x03,0x3F,0x63,0x63,0x7F,0x3E,0x00,0x00},
    ['b'] = {0xC0,0xC0,0xFC,0xFE,0xC3,0xC3,0xFE,0xFC,0x00,0x00},
    ['c'] = {0x00,0x3E,0x7F,0xC0,0xC0,0xC0,0x7F,0x3E,0x00,0x00},
    ['d'] = {0x03,0x03,0x3F,0x7F,0xC3,0xC3,0x7F,0x3F,0x00,0x00},
    ['e'] = {0x00,0x3C,0x7E,0xFF,0xC0,0xC0,0x7E,0x3C,0x00,0x00},
    ['f'] = {0x1E,0x3E,0x30,0xFC,0xFC,0x30,0x30,0x30,0x00,0x00},
    ['g'] = {0x00,0x3F,0x7F,0xC3,0x7F,0x3F,0x03,0x7E,0x00,0x00},
    ['h'] = {0xC0,0xC0,0xFC,0xFE,0xC3,0xC3,0xC3,0xC3,0x00,0x00},
    ['i'] = {0x18,0x00,0x78,0x78,0x18,0x18,0xFF,0xFF,0x00,0x00},
    ['j'] = {0x06,0x00,0x1E,0x1E,0x06,0x06,0xC6,0x7C,0x00,0x00},
    ['k'] = {0xC0,0xC6,0xCC,0xF8,0xF8,0xCC,0xC6,0xC3,0x00,0x00},
    ['l'] = {0x78,0x78,0x18,0x18,0x18,0x18,0xFF,0xFF,0x00,0x00},
    ['m'] = {0x00,0xC3,0xFF,0xFF,0xDB,0xC3,0xC3,0xC3,0x00,0x00},
    ['n'] = {0x00,0xFE,0xFF,0xC3,0xC3,0xC3,0xC3,0xC3,0x00,0x00},
    ['o'] = {0x00,0x3C,0x7E,0xC3,0xC3,0xC3,0x7E,0x3C,0x00,0x00},
    ['p'] = {0x00,0xFC,0xFE,0xC3,0xFE,0xFC,0xC0,0xC0,0x00,0x00},
    ['q'] = {0x00,0x3F,0x7F,0xC3,0x7F,0x3F,0x03,0x03,0x00,0x00},
    ['r'] = {0x00,0xCE,0xFF,0xF3,0xC0,0xC0,0xC0,0xC0,0x00,0x00},
    ['s'] = {0x00,0x7F,0xFF,0xC0,0x7E,0x03,0xFF,0xFE,0x00,0x00},
    ['t'] = {0x30,0xFF,0xFF,0x30,0x30,0x30,0x3F,0x1E,0x00,0x00},
    ['u'] = {0x00,0xC3,0xC3,0xC3,0xC3,0xC3,0xFF,0x7E,0x00,0x00},
    ['v'] = {0x00,0xC3,0xC3,0x66,0x66,0x3C,0x3C,0x18,0x00,0x00},
    ['w'] = {0x00,0xC3,0xC3,0xDB,0xFF,0xFF,0x66,0x42,0x00,0x00},
    ['x'] = {0x00,0xC3,0x66,0x3C,0x18,0x3C,0x66,0xC3,0x00,0x00},
    ['y'] = {0x00,0xC3,0x7E,0x3C,0x18,0x18,0x18,0x18,0x00,0x00},
    ['z'] = {0x00,0xFF,0xFF,0x0C,0x18,0x30,0xFF,0xFF,0x00,0x00},
    ['0'] = {0x3C,0x7E,0xC7,0xCF,0xDB,0xF3,0x7E,0x3C,0x00,0x00},
    ['1'] = {0x18,0x78,0x18,0x18,0x18,0x18,0xFF,0xFF,0x00,0x00},
    ['2'] = {0x7E,0xFF,0x03,0x3E,0x7C,0xC0,0xFF,0xFF,0x00,0x00},
    ['3'] = {0x7E,0xFF,0x03,0x1E,0x1E,0x03,0xFF,0x7E,0x00,0x00},
    ['4'] = {0xC3,0xC3,0xC3,0xFF,0xFF,0x03,0x03,0x03,0x00,0x00},
    ['5'] = {0xFF,0xFF,0xC0,0xFE,0x7F,0x03,0xFF,0xFE,0x00,0x00},
    ['6'] = {0x3E,0x7C,0xC0,0xFE,0xFF,0xC3,0xFF,0x7E,0x00,0x00},
    ['7'] = {0xFF,0xFF,0x03,0x06,0x0C,0x18,0x18,0x18,0x00,0x00},
    ['8'] = {0x7E,0xFF,0xC3,0x7E,0x7E,0xC3,0xFF,0x7E,0x00,0x00},
    ['9'] = {0x7E,0xFF,0xC3,0xFF,0x7F,0x03,0x3E,0x7C,0x00,0x00},
    ['.'] = {0x00,0x00,0x00,0x00,0x00,0x00,0x7E,0x7E,0x00,0x00},
    [','] = {0x00,0x00,0x00,0x00,0x00,0x1C,0x1C,0x38,0x00,0x00},
    ['!'] = {0x18,0x18,0x18,0x18,0x18,0x00,0x18,0x18,0x00,0x00},
    ['?'] = {0x7E,0xFF,0x03,0x1E,0x18,0x00,0x18,0x18,0x00,0x00},
    ['-'] = {0x00,0x00,0x00,0xFF,0xFF,0x00,0x00,0x00,0x00,0x00},
    ['_'] = {0x00,0x00,0x00,0x00,0x00,0x00,0xFF,0xFF,0x00,0x00},
    [':'] = {0x00,0x18,0x18,0x00,0x00,0x18,0x18,0x00,0x00,0x00},
    ['/'] = {0x03,0x06,0x0C,0x18,0x30,0x60,0xC0,0x00,0x00,0x00},
    ['\\']= {0xC0,0x60,0x30,0x18,0x0C,0x06,0x03,0x00,0x00,0x00},
    ['('] = {0x0C,0x18,0x30,0x30,0x30,0x30,0x18,0x0C,0x00,0x00},
    [')'] = {0x30,0x18,0x0C,0x0C,0x0C,0x0C,0x18,0x30,0x00,0x00},
    ['>'] = {0xC0,0x60,0x30,0x18,0x18,0x30,0x60,0xC0,0x00,0x00},
    ['<'] = {0x06,0x0C,0x18,0x30,0x30,0x18,0x0C,0x06,0x00,0x00},
    ['='] = {0x00,0xFF,0xFF,0x00,0x00,0xFF,0xFF,0x00,0x00,0x00},
    ['+'] = {0x00,0x18,0x18,0xFF,0xFF,0x18,0x18,0x00,0x00,0x00},
    ['*'] = {0x00,0xDB,0x7E,0x3C,0x3C,0x7E,0xDB,0x00,0x00,0x00},
    ['#'] = {0x6C,0x6C,0xFF,0x6C,0x6C,0xFF,0x6C,0x6C,0x00,0x00},
    ['%'] = {0xC3,0xC6,0x0C,0x18,0x30,0x63,0xC3,0x00,0x00,0x00},
    ['\'']= {0x18,0x18,0x18,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    ['"'] = {0x66,0x66,0x22,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    ['['] = {0x3C,0x30,0x30,0x30,0x30,0x30,0x30,0x3C,0x00,0x00},
    [']'] = {0x3C,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x3C,0x00,0x00},
    ['@'] = {0x3C,0x7E,0xC3,0xBF,0xBF,0xC0,0x7E,0x3C,0x00,0x00},
    ['&'] = {0x3C,0x66,0x6C,0x38,0x6D,0xC6,0x7F,0x3B,0x00,0x00},
};

void draw_char(int x, int y, char c, unsigned int fg, unsigned int bg) {
    unsigned char uc = (unsigned char)c;
    if (uc > 127) uc = ' ';
    for (int row = 0; row < FONT_H; row++) {
        unsigned char bits = font[uc][row];
        for (int col = 0; col < FONT_W; col++)
            put_pixel(x+col, y+row, (bits&(0x80>>col)) ? fg : bg);
    }
}

void draw_string(int x, int y, const char* str, unsigned int fg, unsigned int bg) {
    for (int i = 0; str[i]; i++)
        draw_char(x+i*FONT_W, y, str[i], fg, bg);
}

int  str_len(const char* s) { int i=0; while(s[i]) i++; return i; }
int  str_eq(const char* a, const char* b) {
    while(*a&&*b){if(*a!=*b)return 0;a++;b++;} return *a==*b;
}
void str_copy(char* d, const char* s) { int i=0; while(s[i]){d[i]=s[i];i++;} d[i]='\0'; }
void int_to_str(unsigned int n, char* buf) {
    if(!n){buf[0]='0';buf[1]='\0';return;}
    char t[16]; int i=0;
    while(n){t[i++]='0'+(n%10);n/=10;}
    for(int j=0;j<i;j++) buf[j]=t[i-j-1]; buf[i]='\0';
}

// ═══════════════════════════════════════════════════════════════════════════════
// MOUSE
// ═══════════════════════════════════════════════════════════════════════════════

static int mouse_x=512,mouse_y=384,mouse_btn=0,mouse_btn_prev=0;
static int right_btn=0,right_btn_prev=0;

void mouse_init() {
    outb(0x64,0xA8); outb(0x64,0x20);
    unsigned char s=inb(0x60); s|=0x02;
    outb(0x64,0x60); outb(0x60,s);
    outb(0x64,0xD4); outb(0x60,0xF4); inb(0x60);
}

void mouse_poll() {
    unsigned char st=inb(0x64);
    if(!(st&0x01)||!(st&0x20)) return;
    unsigned char b1=inb(0x60);
    st=inb(0x64); if(!(st&0x01)||!(st&0x20)) return;
    unsigned char b2=inb(0x60);
    st=inb(0x64); if(!(st&0x01)||!(st&0x20)) return;
    unsigned char b3=inb(0x60);
    mouse_btn_prev=mouse_btn; right_btn_prev=right_btn;
    mouse_btn=b1&0x01; right_btn=(b1&0x02)>>1;
    int dx=(int)b2-((b1<<4)&0x100);
    int dy=-(int)b3+((b1<<3)&0x100);
    mouse_x+=dx; mouse_y+=dy;
    if(mouse_x<0) mouse_x=0;
    if(mouse_x>=(int)fb_width)  mouse_x=fb_width-1;
    if(mouse_y<0) mouse_y=0;
    if(mouse_y>=(int)fb_height) mouse_y=fb_height-1;
}

int mouse_clicked() { return mouse_btn&&!mouse_btn_prev; }
int right_clicked()  { return right_btn&&!right_btn_prev; }

void draw_cursor() {
    for(int i=0;i<14;i++) put_pixel(mouse_x,   mouse_y+i,COL_BLACK);
    for(int i=0;i<10;i++) put_pixel(mouse_x+i, mouse_y,  COL_BLACK);
    for(int i=1;i<10;i++) put_pixel(mouse_x+i, mouse_y+(10-i),COL_BLACK);
    for(int i=1;i<12;i++) put_pixel(mouse_x+1, mouse_y+i,COL_WHITE);
    for(int i=1;i<8; i++) put_pixel(mouse_x+i, mouse_y+1,COL_WHITE);
}

// ═══════════════════════════════════════════════════════════════════════════════
// KEYBOARD
// ═══════════════════════════════════════════════════════════════════════════════

static const char scancode_map[128] = {
    0,0,'1','2','3','4','5','6','7','8','9','0','-','=','\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0,'a','s','d','f','g','h','j','k','l',';','\'','`',
    0,'\\','z','x','c','v','b','n','m',',','.','/',0,
    '*',0,' '
};

char read_key() {
    unsigned char st=inb(0x64);
    if(!(st&0x01)) return 0;
    if(st&0x20)    return 0;
    unsigned char key=inb(0x60);
    if(key&0x80)   return 0;
    if(key<128) return scancode_map[key];
    return 0;
}

// ═══════════════════════════════════════════════════════════════════════════════
// ATA PIO DISK I/O
// ═══════════════════════════════════════════════════════════════════════════════

#define PART2_OFFSET 65536
#define SECTOR_SIZE  512
#define ROOT_START   96
#define ROOT_SECTORS 32
#define DATA_START   158
#define CLUSTER_SIZE 2
#define MAX_FILES    32

void ata_wait()     { while(inb(0x1F7)&0x80); }
void ata_wait_drq() { while(!(inb(0x1F7)&0x08)); }

void ata_read_sector(unsigned int lba, unsigned char* buf) {
    unsigned int rlba=lba+PART2_OFFSET;
    ata_wait();
    outb(0x1F6,0xE0|((rlba>>24)&0x0F));
    outb(0x1F2,1);
    outb(0x1F3,(unsigned char)rlba);
    outb(0x1F4,(unsigned char)(rlba>>8));
    outb(0x1F5,(unsigned char)(rlba>>16));
    outb(0x1F7,0x20);
    ata_wait_drq();
    unsigned short* p=(unsigned short*)buf;
    for(int i=0;i<256;i++){
        unsigned short v;
        __asm__ volatile("inw %1,%0":"=a"(v):"Nd"((unsigned short)0x1F0));
        p[i]=v;
    }
}

void ata_write_sector(unsigned int lba, unsigned char* buf) {
    unsigned int rlba=lba+PART2_OFFSET;
    ata_wait();
    outb(0x1F6,0xE0|((rlba>>24)&0x0F));
    outb(0x1F2,1);
    outb(0x1F3,(unsigned char)rlba);
    outb(0x1F4,(unsigned char)(rlba>>8));
    outb(0x1F5,(unsigned char)(rlba>>16));
    outb(0x1F7,0x30);
    ata_wait_drq();
    unsigned short* p=(unsigned short*)buf;
    for(int i=0;i<256;i++){
        unsigned short v=p[i];
        __asm__ volatile("outw %0,%1"::"a"(v),"Nd"((unsigned short)0x1F0));
    }
    outb(0x1F7,0xE7); ata_wait();
}

void read_sector(unsigned int lba, unsigned char* buf)  { ata_read_sector(lba,buf); }
void write_sector(unsigned int lba, unsigned char* buf) { ata_write_sector(lba,buf); }

// ═══════════════════════════════════════════════════════════════════════════════
// FAT12
// ═══════════════════════════════════════════════════════════════════════════════

typedef struct {
    char           name[8];
    char           ext[3];
    unsigned char  attr;
    unsigned char  reserved[10];
    unsigned short time,date,cluster;
    unsigned int   size;
} __attribute__((packed)) fat_entry_t;

typedef struct {
    char         name[13];
    unsigned int size;
    int          is_dir,is_app;
    unsigned int cluster;
    int          entry_index;
} FileInfo;

static FileInfo file_list[MAX_FILES];
static int      file_count=0;
static char     file_content[4096];
static int      file_content_len=0;

void load_file_list() {
    file_count=0;
    unsigned char buf[SECTOR_SIZE];
    int entry=0, per_sector=SECTOR_SIZE/sizeof(fat_entry_t);
    for(int s=0;s<ROOT_SECTORS&&file_count<MAX_FILES;s++) {
        read_sector(ROOT_START+s,buf);
        fat_entry_t* e=(fat_entry_t*)buf;
        for(int i=0;i<per_sector&&file_count<MAX_FILES;i++,entry++) {
            unsigned char f=(unsigned char)e[i].name[0];
            if(f==0x00) return;
            if(f==0xE5||e[i].attr&0x08||e[i].attr&0x02) continue;
            FileInfo* fi=&file_list[file_count];
            fi->entry_index=entry;
            int k=0;
            for(int j=0;j<8&&e[i].name[j]!=' ';j++) fi->name[k++]=e[i].name[j];
            if(e[i].attr&0x10) {
                fi->name[k++]='/'; fi->name[k]='\0';
                fi->size=0; fi->is_dir=1; fi->is_app=0;
            } else {
                char ext[4]={0};
                int ek=0;
                for(int j=0;j<3&&e[i].ext[j]!=' ';j++) ext[ek++]=e[i].ext[j];
                ext[ek]='\0';
                if(e[i].ext[0]!=' ') {
                    fi->name[k++]='.';
                    for(int j=0;ext[j];j++) fi->name[k++]=ext[j];
                }
                fi->name[k]='\0';
                fi->size=e[i].size; fi->is_dir=0;
                fi->is_app=str_eq(ext,"AEX");
            }
            fi->cluster=e[i].cluster;
            file_count++;
        }
    }
}

void open_file(unsigned int cluster) {
    unsigned int sector=DATA_START+(cluster-2)*CLUSTER_SIZE;
    unsigned char buf[SECTOR_SIZE*CLUSTER_SIZE];
    for(int s=0;s<CLUSTER_SIZE;s++) read_sector(sector+s,buf+s*SECTOR_SIZE);
    file_content_len=0;
    for(int i=0;i<SECTOR_SIZE*CLUSTER_SIZE&&file_content_len<4095;i++) {
        if(!buf[i]) break;
        file_content[file_content_len++]=buf[i];
    }
    file_content[file_content_len]='\0';
}

unsigned int fat_find_free_cluster() {
    unsigned char fat_buf[SECTOR_SIZE];
    for(int s=0;s<9;s++) {
        read_sector(2+s,fat_buf);
        for(int i=0;i<(SECTOR_SIZE*2/3)-1;i++) {
            int bo=(i*3)/2;
            unsigned int val;
            if(i%2==0) val=fat_buf[bo]|((fat_buf[bo+1]&0x0F)<<8);
            else        val=(fat_buf[bo]>>4)|(fat_buf[bo+1]<<4);
            unsigned int cluster=s*(SECTOR_SIZE*2/3)+i+2;
            if(cluster>2&&val==0x000) return cluster;
        }
    }
    return 0;
}

void fat_set_cluster(unsigned int cluster, unsigned int val) {
    unsigned char fat_buf[SECTOR_SIZE];
    unsigned int bit_off=cluster*12;
    unsigned int byte_off=bit_off/8;
    unsigned int fat_sec=2+(byte_off/SECTOR_SIZE);
    unsigned int sec_off=byte_off%SECTOR_SIZE;
    read_sector(fat_sec,fat_buf);
    if(cluster%2==0) {
        fat_buf[sec_off]=(unsigned char)(val&0xFF);
        fat_buf[sec_off+1]=(fat_buf[sec_off+1]&0xF0)|((val>>8)&0x0F);
    } else {
        fat_buf[sec_off]=(fat_buf[sec_off]&0x0F)|((val&0x0F)<<4);
        fat_buf[sec_off+1]=(unsigned char)(val>>4);
    }
    write_sector(fat_sec,fat_buf);
    write_sector(fat_sec+9,fat_buf);
}

void write_cluster(unsigned int cluster, const char* content, unsigned int len) {
    unsigned char buf[SECTOR_SIZE*CLUSTER_SIZE];
    for(int i=0;i<SECTOR_SIZE*CLUSTER_SIZE;i++) buf[i]=0;
    for(unsigned int i=0;i<len&&i<(unsigned int)(SECTOR_SIZE*CLUSTER_SIZE);i++) buf[i]=content[i];
    unsigned int sector=DATA_START+(cluster-2)*CLUSTER_SIZE;
    for(int s=0;s<CLUSTER_SIZE;s++) write_sector(sector+s,buf+s*SECTOR_SIZE);
}

int create_file(const char* name, const char* ext) {
    unsigned int cluster=fat_find_free_cluster();
    if(!cluster) return 0;
    fat_set_cluster(cluster,0xFFF);
    unsigned char empty[SECTOR_SIZE*CLUSTER_SIZE];
    for(int i=0;i<SECTOR_SIZE*CLUSTER_SIZE;i++) empty[i]=0;
    unsigned int sector=DATA_START+(cluster-2)*CLUSTER_SIZE;
    for(int s=0;s<CLUSTER_SIZE;s++) write_sector(sector+s,empty+s*SECTOR_SIZE);
    unsigned char buf[SECTOR_SIZE];
    int per_sector=SECTOR_SIZE/sizeof(fat_entry_t);
    for(int s=0;s<ROOT_SECTORS;s++) {
        read_sector(ROOT_START+s,buf);
        fat_entry_t* e=(fat_entry_t*)buf;
        for(int i=0;i<per_sector;i++) {
            unsigned char f=(unsigned char)e[i].name[0];
            if(f==0x00||f==0xE5) {
                for(int j=0;j<8;j++) e[i].name[j]=' ';
                for(int j=0;j<3;j++) e[i].ext[j]=' ';
                int nk=0; while(name[nk]&&nk<8){e[i].name[nk]=name[nk];nk++;}
                int ek=0; while(ext[ek]&&ek<3){e[i].ext[ek]=ext[ek];ek++;}
                e[i].attr=0x20; e[i].cluster=(unsigned short)cluster;
                e[i].size=0; e[i].time=0; e[i].date=0;
                for(int j=0;j<10;j++) e[i].reserved[j]=0;
                write_sector(ROOT_START+s,buf);
                return 1;
            }
        }
    }
    return 0;
}

void save_file(unsigned int cluster, const char* content, unsigned int len, int entry_index) {
    write_cluster(cluster,content,len);
    unsigned char buf[SECTOR_SIZE];
    int per_sector=SECTOR_SIZE/sizeof(fat_entry_t);
    int s=entry_index/per_sector, i=entry_index%per_sector;
    read_sector(ROOT_START+s,buf);
    fat_entry_t* e=(fat_entry_t*)buf;
    e[i].size=len;
    write_sector(ROOT_START+s,buf);
}

// ═══════════════════════════════════════════════════════════════════════════════
// WINDOW SYSTEM
// ═══════════════════════════════════════════════════════════════════════════════

#define MAX_WINDOWS 8
#define WIN_FILES   0
#define WIN_SHELL   1
#define WIN_VIEWER  2
#define WIN_EDITOR  3

typedef struct {
    int x,y,w,h;
    const char* title;
    int visible,minimized,dragging,drag_ox,drag_oy;
    int focused; // which input this window owns
} Window;

static Window windows[MAX_WINDOWS];
static int    win_count=0;
static int    focused_win=-1; // which window has input focus

void add_window(int x,int y,int w,int h,const char* title) {
    if(win_count>=MAX_WINDOWS) return;
    Window* wn=&windows[win_count++];
    wn->x=x;wn->y=y;wn->w=w;wn->h=h;
    wn->title=title;wn->visible=1;wn->minimized=0;wn->dragging=0;
}

void focus_window(int i) {
    focused_win=i;
}

void draw_window_frame(int i) {
    Window* w=&windows[i];
    if(!w->visible||w->minimized) return;
    int focused=(focused_win==i);
    draw_rect(w->x+4,w->y+4,w->w,w->h,COL_SHADOW);
    draw_rect(w->x,w->y,w->w,w->h,COL_WINBG);
    unsigned int tbg=focused?COL_TITLEBG:0x00404060;
    draw_rect(w->x,w->y,w->w,22,tbg);
    draw_string(w->x+6,w->y+6,w->title,COL_TITLEFG,tbg);
    // Minimize button
    draw_rect(w->x+w->w-44,w->y+3,18,16,COL_MINBTN);
    draw_rect_outline(w->x+w->w-44,w->y+3,18,16,COL_BLACK);
    draw_rect(w->x+w->w-40,w->y+14,10,3,COL_WHITE);
    // Close button
    draw_rect(w->x+w->w-22,w->y+3,18,16,COL_RED);
    draw_rect_outline(w->x+w->w-22,w->y+3,18,16,COL_BLACK);
    draw_string(w->x+w->w-18,w->y+5,"X",COL_WHITE,COL_RED);
    draw_rect_outline(w->x,w->y,w->w,w->h,COL_BLACK);
}

// ═══════════════════════════════════════════════════════════════════════════════
// TASKBAR
// ═══════════════════════════════════════════════════════════════════════════════

void draw_taskbar() {
    int tb_y=(int)fb_height-36;
    draw_rect(0,tb_y,fb_width,36,COL_TASKBAR);
    draw_rect(0,tb_y,fb_width,1,COL_DARK);

    // AerOS start label
    draw_rect(4,tb_y+4,80,28,COL_TASKACT);
    draw_rect_outline(4,tb_y+4,80,28,COL_BLUE);
    draw_string(14,tb_y+13,"AerOS",COL_WHITE,COL_TASKACT);

    // Window buttons
    int bx=92;
    for(int i=0;i<win_count;i++) {
        if(!windows[i].visible) continue;
        unsigned int bbg=(focused_win==i)?COL_TASKACT:COL_TASKBTN;
        draw_rect(bx,tb_y+4,110,28,bbg);
        draw_rect_outline(bx,tb_y+4,110,28,COL_DARK);
        // Minimized indicator
        if(windows[i].minimized) {
            draw_string(bx+6,tb_y+13,windows[i].title,COL_DARK,bbg);
        } else {
            draw_string(bx+6,tb_y+13,windows[i].title,COL_WHITE,bbg);
        }
        bx+=116;
    }

    // Clock
    draw_string(fb_width-80,tb_y+13,"12:00 AM",COL_WHITE,COL_TASKBAR);
}

// ═══════════════════════════════════════════════════════════════════════════════
// MENUBAR
// ═══════════════════════════════════════════════════════════════════════════════

static int file_menu_open=0;

void draw_menubar() {
    draw_rect(0,0,fb_width,24,COL_MENUBAR);
    draw_rect_outline(0,0,fb_width,24,COL_DARK);
    unsigned int fbg=file_menu_open?COL_MENUHOV:COL_MENUBAR;
    unsigned int ffg=file_menu_open?COL_WHITE:COL_BLACK;
    draw_rect(0,0,50,24,fbg);
    draw_string(10,7,"File",ffg,fbg);
    draw_string(60, 7,"Edit", COL_BLACK,COL_MENUBAR);
    draw_string(110,7,"View", COL_BLACK,COL_MENUBAR);
    draw_string(160,7,"About",COL_BLACK,COL_MENUBAR);

    if(file_menu_open) {
        draw_rect(0,24,140,70,COL_WINBG);
        draw_rect_outline(0,24,140,70,COL_BLACK);
        // New File
        unsigned int n1bg=(mouse_y>=26&&mouse_y<=46&&mouse_x<=140)?COL_SELBG:COL_WINBG;
        draw_rect(1,26,138,20,n1bg);
        draw_string(8,30,"New File",n1bg==COL_SELBG?COL_WHITE:COL_BLACK,n1bg);
        // Open Shell
        unsigned int n2bg=(mouse_y>=46&&mouse_y<=66&&mouse_x<=140)?COL_SELBG:COL_WINBG;
        draw_rect(1,46,138,20,n2bg);
        draw_string(8,50,"Open Shell",n2bg==COL_SELBG?COL_WHITE:COL_BLACK,n2bg);
        // Quit
        unsigned int n3bg=(mouse_y>=66&&mouse_y<=86&&mouse_x<=140)?COL_SELBG:COL_WINBG;
        draw_rect(1,66,138,20,n3bg);
        draw_string(8,70,"Quit",n3bg==COL_SELBG?COL_WHITE:COL_BLACK,n3bg);
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// FILE EXPLORER
// ═══════════════════════════════════════════════════════════════════════════════

static int selected_file=-1;
static int ctx_visible=0,ctx_x=0,ctx_y=0,ctx_file=-1;

void draw_file_explorer() {
    Window* w=&windows[WIN_FILES];
    if(!w->visible||w->minimized) return;
    int cx=w->x+1,cy=w->y+23,cw=w->w-2,ch=w->h-24;
    draw_rect(cx,cy,cw,ch,COL_WHITE);
    draw_rect(cx,cy,cw,FONT_H+6,COL_DARK);
    draw_string(cx+6,cy+3,"Name",COL_WHITE,COL_DARK);
    draw_string(cx+cw-70,cy+3,"Size",COL_WHITE,COL_DARK);
    draw_rect(cx,cy+FONT_H+6,cw,1,COL_BLACK);
    int row_h=FONT_H+5,list_y=cy+FONT_H+8;
    for(int i=0;i<file_count;i++) {
        int fy=list_y+i*row_h;
        if(fy+FONT_H>cy+ch-2) break;
        unsigned int bg=(i==selected_file)?COL_SELBG:(i%2==0?0x00EEEEEE:COL_WHITE);
        unsigned int fg=(i==selected_file)?COL_SELFG:file_list[i].is_app?0x00008800:file_list[i].is_dir?COL_BLUE:COL_BLACK;
        draw_rect(cx,fy,cw,row_h,bg);
        draw_string(cx+6,fy+2,file_list[i].name,fg,bg);
        if(!file_list[i].is_dir&&!file_list[i].is_app) {
            char sz[12]; unsigned int s=file_list[i].size;
            if(s<1024){int_to_str(s,sz);int k=str_len(sz);sz[k]='B';sz[k+1]='\0';}
            else{int_to_str(s/1024,sz);int k=str_len(sz);sz[k]='K';sz[k+1]='\0';}
            draw_string(cx+cw-70,fy+2,sz,fg,bg);
        } else if(file_list[i].is_app) {
            draw_string(cx+cw-70,fy+2,"App",fg,bg);
        }
    }
    if(file_count==0) draw_string(cx+10,list_y+4,"No files found.",COL_DARK,COL_WHITE);
}

// ═══════════════════════════════════════════════════════════════════════════════
// SHELL
// ═══════════════════════════════════════════════════════════════════════════════

static char shell_input[128];
static int  shell_input_len=0;
static char shell_lines[14][84];
static int  shell_line_count=0;

void shell_println(const char* str) {
    if(shell_line_count<14) {
        int i=0; while(str[i]&&i<82){shell_lines[shell_line_count][i]=str[i];i++;}
        shell_lines[shell_line_count][i]='\0'; shell_line_count++;
    } else {
        for(int i=0;i<13;i++){int j=0;while(shell_lines[i+1][j]){shell_lines[i][j]=shell_lines[i+1][j];j++;}shell_lines[i][j]='\0';}
        int i=0; while(str[i]&&i<82){shell_lines[13][i]=str[i];i++;} shell_lines[13][i]='\0';
    }
}

void shell_run(const char* cmd) {
    if(str_eq(cmd,"help"))  shell_println("Commands: help clear ver files");
    else if(str_eq(cmd,"clear")) shell_line_count=0;
    else if(str_eq(cmd,"ver"))   shell_println("AerOS build 2600.0001");
    else if(str_eq(cmd,"files")) {
        shell_println("Files on disk:");
        for(int i=0;i<file_count;i++) shell_println(file_list[i].name);
    } else if(cmd[0]!='\0') shell_println("Unknown command. Type help.");
}

void draw_shell_content() {
    Window* w=&windows[WIN_SHELL];
    if(!w->visible||w->minimized) return;
    int cx=w->x+1,cy=w->y+23,cw=w->w-2,ch=w->h-24;
    draw_rect(cx,cy,cw,ch,COL_TERMINAL);
    for(int i=0;i<shell_line_count;i++)
        draw_string(cx+4,cy+4+i*(FONT_H+2),shell_lines[i],COL_TERMFG,COL_TERMINAL);
    int iy=cy+ch-FONT_H-8;
    draw_rect(cx,iy-2,cw,FONT_H+6,0x00002800);
    draw_string(cx+4,iy,"AerOS> ",0x0000FF44,0x00002800);
    draw_string(cx+4+7*FONT_W,iy,shell_input,COL_WHITE,0x00002800);
    if(focused_win==WIN_SHELL)
        draw_rect(cx+4+(7+shell_input_len)*FONT_W,iy+FONT_H,FONT_W,2,COL_WHITE);
}

// ═══════════════════════════════════════════════════════════════════════════════
// FILE VIEWER
// ═══════════════════════════════════════════════════════════════════════════════

void draw_file_viewer() {
    Window* w=&windows[WIN_VIEWER];
    if(!w->visible||w->minimized) return;
    int cx=w->x+1,cy=w->y+23,cw=w->w-2,ch=w->h-24;
    draw_rect(cx,cy,cw,ch,COL_WHITE);
    int x=cx+6,y=cy+6,max_w=(cw-12)/FONT_W,col=0;
    for(int i=0;i<file_content_len;i++) {
        char c=file_content[i];
        if(c=='\n'||col>=max_w){y+=FONT_H+2;col=0;if(c=='\n')continue;}
        if(y+FONT_H>cy+ch-4) break;
        draw_char(x+col*FONT_W,y,c,COL_BLACK,COL_WHITE); col++;
    }
    if(!file_content_len) draw_string(cx+6,cy+6,"Empty file.",COL_DARK,COL_WHITE);
}

// ═══════════════════════════════════════════════════════════════════════════════
// FILE EDITOR
// ═══════════════════════════════════════════════════════════════════════════════

static char editor_buf[4096];
static int  editor_len=0,editor_cursor=0,editor_file=-1,editor_saved=1;

void editor_open(int idx) {
    editor_file=idx;
    open_file(file_list[idx].cluster);
    str_copy(editor_buf,file_content);
    editor_len=file_content_len;
    editor_cursor=editor_len;
    editor_saved=1;
    windows[WIN_EDITOR].visible=1;
    windows[WIN_EDITOR].minimized=0;
    focus_window(WIN_EDITOR);
}

void editor_save() {
    if(editor_file<0) return;
    save_file(file_list[editor_file].cluster,editor_buf,editor_len,file_list[editor_file].entry_index);
    editor_saved=1; load_file_list();
}

void editor_handle_key(char c) {
    if(!c) return;
    editor_saved=0;
    if(c=='\b'){if(editor_cursor>0){for(int i=editor_cursor-1;i<editor_len-1;i++)editor_buf[i]=editor_buf[i+1];editor_len--;editor_cursor--;editor_buf[editor_len]='\0';}}
    else if(editor_len<4094){for(int i=editor_len;i>editor_cursor;i--)editor_buf[i]=editor_buf[i-1];editor_buf[editor_cursor]=c;editor_len++;editor_cursor++;editor_buf[editor_len]='\0';}
}

void draw_editor() {
    Window* w=&windows[WIN_EDITOR];
    if(!w->visible||w->minimized) return;
    int cx=w->x+1,cy=w->y+23,cw=w->w-2,ch=w->h-24;
    draw_rect(cx,cy,cw,ch,COL_WHITE);
    // Toolbar
    draw_rect(cx,cy,cw,22,0x00E0E0E0);
    draw_rect_outline(cx,cy,cw,22,COL_DARK);
    unsigned int sbg=editor_saved?COL_GRAY:0x0000AA00;
    draw_rect(cx+4,cy+3,55,16,sbg);
    draw_rect_outline(cx+4,cy+3,55,16,COL_BLACK);
    draw_string(cx+8,cy+6,"Save",editor_saved?COL_BLACK:COL_WHITE,sbg);
    if(editor_file>=0) draw_string(cx+68,cy+6,file_list[editor_file].name,COL_BLACK,0x00E0E0E0);
    // Text area
    int tx=cx+4,ty=cy+26,max_w=(cw-8)/FONT_W;
    int col=0,row=0,cur_col=0,cur_row=0;
    for(int i=0;i<=editor_len;i++) {
        if(i==editor_cursor){cur_col=col;cur_row=row;}
        if(i==editor_len) break;
        char c=editor_buf[i];
        if(c=='\n'||col>=max_w){if(c!='\n')draw_char(tx+col*FONT_W,ty+row*(FONT_H+2),c,COL_BLACK,COL_WHITE);col=0;row++;if(c=='\n')continue;}
        if(ty+row*(FONT_H+2)+FONT_H>cy+ch-4) break;
        draw_char(tx+col*FONT_W,ty+row*(FONT_H+2),c,COL_BLACK,COL_WHITE); col++;
    }
    if(focused_win==WIN_EDITOR)
        draw_rect(tx+cur_col*FONT_W,ty+cur_row*(FONT_H+2),2,FONT_H,COL_BLACK);
}

// ═══════════════════════════════════════════════════════════════════════════════
// NEW FILE DIALOG
// ═══════════════════════════════════════════════════════════════════════════════

static int  nf_visible=0,nf_focus=0;
static char nf_name[9],nf_ext[4];
static int  nf_name_len=0,nf_ext_len=0;

void draw_newfile_dialog() {
    if(!nf_visible) return;
    int ax=(int)fb_width/2-180,ay=(int)fb_height/2-80,aw=360,ah=160;
    draw_rect(ax+4,ay+4,aw,ah,COL_SHADOW);
    draw_rect(ax,ay,aw,ah,COL_WINBG);
    draw_rect(ax,ay,aw,22,COL_TITLEBG);
    draw_string(ax+6,ay+6,"New File",COL_TITLEFG,COL_TITLEBG);
    draw_rect_outline(ax,ay,aw,ah,COL_BLACK);
    draw_string(ax+20,ay+32,"Filename (max 8):",COL_BLACK,COL_WINBG);
    unsigned int nbg=nf_focus==0?COL_WHITE:0x00EEEEEE;
    draw_rect(ax+20,ay+46,160,18,nbg);
    draw_rect_outline(ax+20,ay+46,160,18,nf_focus==0?COL_BLUE:COL_BLACK);
    draw_string(ax+24,ay+49,nf_name,COL_BLACK,nbg);
    draw_string(ax+20,ay+72,"Extension (max 3):",COL_BLACK,COL_WINBG);
    unsigned int ebg=nf_focus==1?COL_WHITE:0x00EEEEEE;
    draw_rect(ax+20,ay+86,60,18,ebg);
    draw_rect_outline(ax+20,ay+86,60,18,nf_focus==1?COL_BLUE:COL_BLACK);
    draw_string(ax+24,ay+89,nf_ext,COL_BLACK,ebg);
    int bx=ax+aw-160,by=ay+ah-26;
    draw_rect(bx,by,70,20,COL_GRAY); draw_rect_outline(bx,by,70,20,COL_BLACK);
    draw_string(bx+18,by+5,"OK",COL_BLACK,COL_GRAY);
    draw_rect(bx+80,by,70,20,COL_GRAY); draw_rect_outline(bx+80,by,70,20,COL_BLACK);
    draw_string(bx+88,by+5,"Cancel",COL_BLACK,COL_GRAY);
}

// ═══════════════════════════════════════════════════════════════════════════════
// ABOUT DIALOG
// ═══════════════════════════════════════════════════════════════════════════════

static int about_visible=0;

void draw_about_dialog() {
    if(!about_visible) return;
    int ax=(int)fb_width/2-220,ay=(int)fb_height/2-120,aw=440,ah=240;
    draw_rect(ax+4,ay+4,aw,ah,COL_SHADOW);
    draw_rect(ax,ay,aw,ah,COL_WINBG);
    draw_rect(ax,ay,aw,22,COL_TITLEBG);
    draw_string(ax+6,ay+6,"About AerOS",COL_TITLEFG,COL_TITLEBG);
    draw_rect_outline(ax,ay,aw,ah,COL_BLACK);
    int tx=ax+20,ty=ay+32;
    draw_string(tx,ty,    "Frutiger Aero Operating System",COL_BLACK,COL_WINBG);
    draw_string(tx,ty+18, "Version build 2600.0001",       COL_BLACK,COL_WINBG);
    draw_string(tx,ty+36, "Copyright (C) 2026, Cotrlin AerOS",COL_DARK,COL_WINBG);
    draw_rect(ax+1,ay+ah-75,aw-2,1,COL_DARK);
    char ds[40],ms[40],num[16];
    int_to_str(48*1024-file_count*20,num);
    int k=0; const char* dl="Disk space free: ";
    while(dl[k]){ds[k]=dl[k];k++;} for(int i=0;num[i];i++)ds[k++]=num[i]; ds[k++]='K';ds[k]='\0';
    int_to_str(32768,num); k=0; const char* ml="Memory free: ";
    while(ml[k]){ms[k]=ml[k];k++;} for(int i=0;num[i];i++)ms[k++]=num[i]; ms[k++]='K';ms[k]='\0';
    draw_string(tx,ay+ah-65,ds,COL_BLACK,COL_WINBG);
    draw_string(tx,ay+ah-47,ms,COL_BLACK,COL_WINBG);
    int bx=ax+aw/2-35,by=ay+ah-26;
    draw_rect(bx,by,70,20,COL_GRAY); draw_rect_outline(bx,by,70,20,COL_BLACK);
    draw_string(bx+22,by+5,"Ok",COL_BLACK,COL_GRAY);
    if(mouse_clicked()&&mouse_x>=bx&&mouse_x<=bx+70&&mouse_y>=by&&mouse_y<=by+20)
        about_visible=0;
}

// ═══════════════════════════════════════════════════════════════════════════════
// CONTEXT MENU
// ═══════════════════════════════════════════════════════════════════════════════

void draw_context_menu() {
    if(!ctx_visible) return;
    int mw=120,mh=60;
    draw_rect(ctx_x+2,ctx_y+2,mw,mh,COL_SHADOW);
    draw_rect(ctx_x,ctx_y,mw,mh,COL_WINBG);
    draw_rect_outline(ctx_x,ctx_y,mw,mh,COL_BLACK);
    unsigned int b1=(mouse_y>=ctx_y+2&&mouse_y<=ctx_y+22&&mouse_x>=ctx_x&&mouse_x<=ctx_x+mw)?COL_SELBG:COL_WINBG;
    draw_rect(ctx_x+1,ctx_y+2,mw-2,20,b1); draw_string(ctx_x+8,ctx_y+6,"Open",b1==COL_SELBG?COL_WHITE:COL_BLACK,b1);
    unsigned int b2=(mouse_y>=ctx_y+22&&mouse_y<=ctx_y+42&&mouse_x>=ctx_x&&mouse_x<=ctx_x+mw)?COL_SELBG:COL_WINBG;
    draw_rect(ctx_x+1,ctx_y+22,mw-2,20,b2); draw_string(ctx_x+8,ctx_y+26,"Edit",b2==COL_SELBG?COL_WHITE:COL_BLACK,b2);
    unsigned int b3=(mouse_y>=ctx_y+42&&mouse_y<=ctx_y+62&&mouse_x>=ctx_x&&mouse_x<=ctx_x+mw)?COL_SELBG:COL_WINBG;
    draw_rect(ctx_x+1,ctx_y+42,mw-2,18,b3); draw_string(ctx_x+8,ctx_y+46,"Delete",b3==COL_SELBG?COL_WHITE:COL_RED,b3);
}

// ═══════════════════════════════════════════════════════════════════════════════
// INPUT
// ═══════════════════════════════════════════════════════════════════════════════

void handle_keyboard(char c) {
    if(!c) return;

    // New file dialog
    if(nf_visible) {
        if(c=='\n'&&nf_name_len>0){create_file(nf_name,nf_ext);load_file_list();nf_visible=0;nf_name[0]='\0';nf_name_len=0;nf_ext[0]='\0';nf_ext_len=0;}
        else if(c=='\t') nf_focus=1-nf_focus;
        else if(c=='\b'){if(nf_focus==0&&nf_name_len>0)nf_name[--nf_name_len]='\0';else if(nf_focus==1&&nf_ext_len>0)nf_ext[--nf_ext_len]='\0';}
        else{if(nf_focus==0&&nf_name_len<8){nf_name[nf_name_len++]=c;nf_name[nf_name_len]='\0';}else if(nf_focus==1&&nf_ext_len<3){nf_ext[nf_ext_len++]=c;nf_ext[nf_ext_len]='\0';}}
        return;
    }

    // Route to focused window
    if(focused_win==WIN_EDITOR&&windows[WIN_EDITOR].visible&&!windows[WIN_EDITOR].minimized) {
        editor_handle_key(c); return;
    }

    if(focused_win==WIN_SHELL&&windows[WIN_SHELL].visible&&!windows[WIN_SHELL].minimized) {
        if(c=='\n'){
            shell_input[shell_input_len]='\0';
            char echo[128]; int k=0; echo[k++]='>'; echo[k++]=' ';
            for(int i=0;shell_input[i];i++) echo[k++]=shell_input[i]; echo[k]='\0';
            shell_println(echo); shell_run(shell_input);
            shell_input_len=0; shell_input[0]='\0';
        } else if(c=='\b'){if(shell_input_len>0) shell_input[--shell_input_len]='\0';}
        else if(shell_input_len<80){shell_input[shell_input_len++]=c;shell_input[shell_input_len]='\0';}
    }
}

void handle_mouse_input() {
    int clicked=mouse_clicked(), rclicked=right_clicked();

    // About dialog
    if(about_visible) { if(clicked) {int ax=(int)fb_width/2-220,ay=(int)fb_height/2-120,aw=440,ah=240,bx=ax+aw/2-35,by=ay+ah-26;if(mouse_x>=bx&&mouse_x<=bx+70&&mouse_y>=by&&mouse_y<=by+20)about_visible=0;} return; }

    // New file dialog
    if(nf_visible) {
        if(clicked) {
            int ax=(int)fb_width/2-180,ay=(int)fb_height/2-80,aw=360,ah=160;
            int bx=ax+aw-160,by=ay+ah-26;
            if(mouse_x>=ax+20&&mouse_x<=ax+180&&mouse_y>=ay+46&&mouse_y<=ay+64){nf_focus=0;return;}
            if(mouse_x>=ax+20&&mouse_x<=ax+80&&mouse_y>=ay+86&&mouse_y<=ay+104){nf_focus=1;return;}
            if(mouse_x>=bx&&mouse_x<=bx+70&&mouse_y>=by&&mouse_y<=by+20){if(nf_name_len>0){create_file(nf_name,nf_ext);load_file_list();}nf_visible=0;return;}
            if(mouse_x>=bx+80&&mouse_x<=bx+150&&mouse_y>=by&&mouse_y<=by+20){nf_visible=0;return;}
        }
        return;
    }

    // Context menu
    if(ctx_visible) {
        if(clicked) {
            int mw=120;
            if(mouse_x>=ctx_x&&mouse_x<=ctx_x+mw) {
                if(mouse_y>=ctx_y+2&&mouse_y<=ctx_y+22) {
                    if(ctx_file>=0&&!file_list[ctx_file].is_dir){selected_file=ctx_file;open_file(file_list[ctx_file].cluster);windows[WIN_VIEWER].visible=1;windows[WIN_VIEWER].minimized=0;focus_window(WIN_VIEWER);}
                    ctx_visible=0; return;
                }
                if(mouse_y>=ctx_y+22&&mouse_y<=ctx_y+42) {
                    if(ctx_file>=0&&!file_list[ctx_file].is_dir){selected_file=ctx_file;editor_open(ctx_file);}
                    ctx_visible=0; return;
                }
                if(mouse_y>=ctx_y+42&&mouse_y<=ctx_y+60) {
                    if(ctx_file>=0){unsigned char buf[SECTOR_SIZE];int per=SECTOR_SIZE/sizeof(fat_entry_t),ei=file_list[ctx_file].entry_index,s=ei/per,i=ei%per;read_sector(ROOT_START+s,buf);buf[i*sizeof(fat_entry_t)]=0xE5;write_sector(ROOT_START+s,buf);load_file_list();selected_file=-1;}
                    ctx_visible=0; return;
                }
            }
            ctx_visible=0;
        }
        return;
    }

    // File menu dropdown
    if(file_menu_open&&clicked) {
        if(mouse_y>=26&&mouse_y<=46&&mouse_x<=140){file_menu_open=0;nf_visible=1;nf_focus=0;nf_name[0]='\0';nf_name_len=0;nf_ext[0]='\0';nf_ext_len=0;return;}
        if(mouse_y>=46&&mouse_y<=66&&mouse_x<=140){file_menu_open=0;windows[WIN_SHELL].visible=1;windows[WIN_SHELL].minimized=0;focus_window(WIN_SHELL);return;}
        if(mouse_y>=66&&mouse_y<=86&&mouse_x<=140){file_menu_open=0;for(int i=0;i<win_count;i++)windows[i].visible=0;return;}
        file_menu_open=0;
    }

    // Menubar clicks
    if(clicked&&mouse_y>=0&&mouse_y<=24) {
        if(mouse_x>=0&&mouse_x<=50){file_menu_open=!file_menu_open;return;}
        if(mouse_x>=160&&mouse_x<=210){about_visible=1;return;}
    }

    // Taskbar clicks
    int tb_y=(int)fb_height-36;
    if(clicked&&mouse_y>=tb_y&&mouse_y<=tb_y+36) {
        int bx=92;
        for(int i=0;i<win_count;i++) {
            if(!windows[i].visible){bx+=116;continue;}
            if(mouse_x>=bx&&mouse_x<=bx+110) {
                if(windows[i].minimized){windows[i].minimized=0;focus_window(i);}
                else if(focused_win==i){windows[i].minimized=1;focused_win=-1;}
                else focus_window(i);
                return;
            }
            bx+=116;
        }
    }

    // Editor save button
    if(clicked&&windows[WIN_EDITOR].visible&&!windows[WIN_EDITOR].minimized) {
        Window* we=&windows[WIN_EDITOR];
        int cx=we->x+1,cy=we->y+23;
        if(mouse_x>=cx+4&&mouse_x<=cx+59&&mouse_y>=cy+3&&mouse_y<=cy+19){editor_save();return;}
    }

    // Window title bar, minimize, close
    if(clicked) {
        for(int i=win_count-1;i>=0;i--) {
            Window* w=&windows[i];
            if(!w->visible||w->minimized) continue;
            // Close
            if(mouse_x>=w->x+w->w-22&&mouse_x<=w->x+w->w-4&&mouse_y>=w->y+3&&mouse_y<=w->y+19){w->visible=0;if(focused_win==i)focused_win=-1;return;}
            // Minimize
            if(mouse_x>=w->x+w->w-44&&mouse_x<=w->x+w->w-26&&mouse_y>=w->y+3&&mouse_y<=w->y+19){w->minimized=1;if(focused_win==i)focused_win=-1;return;}
            // Title bar drag
            if(mouse_x>=w->x&&mouse_x<=w->x+w->w&&mouse_y>=w->y&&mouse_y<=w->y+22){w->dragging=1;w->drag_ox=mouse_x-w->x;w->drag_oy=mouse_y-w->y;focus_window(i);return;}
            // Click inside window body = focus
            if(mouse_x>=w->x&&mouse_x<=w->x+w->w&&mouse_y>=w->y&&mouse_y<=w->y+w->h){focus_window(i);break;}
        }
    }

    // File explorer row click
    if(clicked) {
        Window* wf=&windows[WIN_FILES];
        if(wf->visible&&!wf->minimized) {
            int row_h=FONT_H+5,list_y=wf->y+23+FONT_H+8;
            for(int i=0;i<file_count;i++) {
                int fy=list_y+i*row_h;
                if(mouse_x>=wf->x+1&&mouse_x<=wf->x+wf->w-1&&mouse_y>=fy&&mouse_y<=fy+row_h) {
                    selected_file=i;
                    if(!file_list[i].is_dir&&!file_list[i].is_app){open_file(file_list[i].cluster);windows[WIN_VIEWER].visible=1;windows[WIN_VIEWER].minimized=0;focus_window(WIN_VIEWER);}
                    return;
                }
            }
        }
    }

    // Right click context menu
    if(rclicked) {
        ctx_visible=0;
        Window* wf=&windows[WIN_FILES];
        if(wf->visible&&!wf->minimized) {
            int row_h=FONT_H+5,list_y=wf->y+23+FONT_H+8;
            for(int i=0;i<file_count;i++) {
                int fy=list_y+i*row_h;
                if(mouse_x>=wf->x+1&&mouse_x<=wf->x+wf->w-1&&mouse_y>=fy&&mouse_y<=fy+row_h){ctx_visible=1;ctx_x=mouse_x;ctx_y=mouse_y;ctx_file=i;return;}
            }
        }
    }

    // Drag update
    for(int i=0;i<win_count;i++) {
        Window* w=&windows[i];
        if(!w->dragging) continue;
        if(mouse_btn){w->x=mouse_x-w->drag_ox;w->y=mouse_y-w->drag_oy;}
        else w->dragging=0;
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// KERNEL ENTRY
// ═══════════════════════════════════════════════════════════════════════════════

void kernel_main(unsigned int magic, multiboot_info_t* mbi) {
    if(magic!=0x2BADB002) return;
    if(!(mbi->flags&(1<<12))) return;

    framebuffer=(unsigned int*)(unsigned int)mbi->framebuffer_addr;
    fb_width=mbi->framebuffer_width;
    fb_height=mbi->framebuffer_height;
    fb_pitch=mbi->framebuffer_pitch;

    mouse_init();
    load_file_list();

    shell_line_count=0;
    shell_println("Welcome to AerOS v0.1");
    shell_println("Type 'help' for commands.");

    // Only open File Explorer on boot
    add_window(200,80,600,400,"File Explorer");
    add_window(50, 60,500,380,"AerOS Shell");
    add_window(180,140,420,280,"File Viewer");
    add_window(100,80,500,360,"File Editor");

    windows[WIN_SHELL].visible=0;
    windows[WIN_VIEWER].visible=0;
    windows[WIN_EDITOR].visible=0;

    focus_window(WIN_FILES);

    static int last_mx=-1,last_my=-1,last_btn=-1,redraw=1;

    while(1) {
        mouse_poll();
        char c=read_key();
        if(c){handle_keyboard(c);redraw=1;}
        handle_mouse_input();

        int dirty=redraw;
        for(int i=0;i<win_count;i++) if(windows[i].dragging) dirty=1;
        if(mouse_x!=last_mx||mouse_y!=last_my||mouse_btn!=last_btn) dirty=1;

        if(dirty) {
            draw_rect(0,0,fb_width,fb_height,COL_DESKTOP);

            draw_window_frame(WIN_FILES); draw_file_explorer();
            draw_window_frame(WIN_SHELL); draw_shell_content();
            draw_window_frame(WIN_VIEWER); draw_file_viewer();
            draw_window_frame(WIN_EDITOR); draw_editor();

            draw_menubar();
            draw_taskbar();
            draw_context_menu();
            draw_newfile_dialog();
            draw_about_dialog();
            draw_cursor();
            flush();

            last_mx=mouse_x; last_my=mouse_y; last_btn=mouse_btn;
            redraw=0;
        }
    }
}